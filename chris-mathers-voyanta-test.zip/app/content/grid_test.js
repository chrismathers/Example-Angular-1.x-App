'use strict';

describe('myApp.grid module', function() {

  beforeEach(module('myApp.grid'));

  describe('grid controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var gridCtrl = $controller('gridCtrl');
      expect(gridCtrl).toBeDefined();
    }));

  });
});